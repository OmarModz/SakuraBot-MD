import axios from 'axios'
import fetch from 'node-fetch'

let handler = async (m, { conn, args, text, isPrems, isOwner, usedPrefix, command }) => {
  if (!args || !args[0]) return conn.reply(m.chat, `*• Ingresa un enlace Spotify*`, m)
  await m.react('🕓')
  try {
    let user = global.db.data.users[m.sender]
    let response = await axios.get(`https://api.cafirexos.com/api/spotifyinfo?url=${args[0]}`)
    let { title, artist, album, year, thumbnail, url } = response.data.spty.resultado
    let downloadLink = response.data.spty.download.audio
    let img = await (await fetch(thumbnail)).buffer()

    let txt = `\t\t\t*乂  S P O T I F Y  -  D O W N L O A D*\n\n`
    txt += `*Titulo ∙* ${title}\n`
    txt += `*Artista ∙* ${artist}\n`
    txt += `*Album  ∙* ${album}\n`
    txt += `*Fecha de lanzamiento ∙* ${year}\n\n`
    txt += `- El audio se esta enviando, Espere un momento.`

    await conn.sendMessage(m.chat, {
      text: txt,
      contextInfo: {
        forwardingScore: 9999,
        isForwarded: true,
        externalAdReply: {
          title: botname,
          body: textbot,
          thumbnailUrl: img,
          thumbnail: img,
          sourceUrl: null,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })

    await conn.sendFile(m.chat, downloadLink, title + '.mp3', `
    `.trim(), m, false, { mimetype: 'audio/mpeg', asDocument: user.useDocument })
    await m.react('✅')
  } catch (error) {
    m.reply(`${global.error}`)
  }
}
handler.tags = ['downloader']
handler.help = ['spotifydl *<url spotify>*']
handler.command = ['spotifydl']
handler.limit = 1
handler.register = true
export default handler