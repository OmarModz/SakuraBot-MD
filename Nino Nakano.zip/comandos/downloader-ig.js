/* 
Código By BrunoSobrino
*/

import fetch from 'node-fetch';
import axios from 'axios';
import instagramGetUrl from 'instagram-url-direct';
import {instagram} from '@xct007/frieren-scraper';
import {instagramdl} from '@bochilteam/scraper';
import instagramDl from '@sasmeee/igdl';
import {fileTypeFromBuffer} from 'file-type';
const handler = async (m, {conn, args, command, usedPrefix}) => {
  if (!args[0]) throw `*• Ingresa el enlace del vídeo de Instagram*`;
  await conn.sendMessage(m.chat, { react: { text: '🕜', key: m.key }});
  try {
const img = await instagramDl(args[0]);
for (let i = 0; i < img.length; i++) {
    const bufferInfo = await getBuffer(img[i].download_link);
        if (bufferInfo.detectedType.mime.startsWith('image/')) {
            await await conn.sendFile(m.chat, img[i].download_link, 'error.mp4', '*Aqui tiene ฅ^•ﻌ•^ฅ*', m);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
        } else if (bufferInfo.detectedType.mime.startsWith('video/')) {
            await conn.sendFile(m.chat, img[i].download_link, 'error.mp4', '*Aqui tiene ฅ^•ﻌ•^ฅ*', m);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
        }
}
  } catch {   
  try {
    const datTa = await instagram.download(args[0]);
    for (const urRRl of datTa) {
      const shortUrRRl = await (await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`)).text();
      conn.sendFile(m.chat, urRRl.url, 'error.mp4', '*Aqui tiene ฅ^•ﻌ•^ฅ*', m);
      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
      await new Promise((resolve) => setTimeout(resolve, 10000));
    }
  } catch {
      try {
        const resultss = await instagramGetUrl(args[0]).url_list[0];
        const shortUrl2 = await (await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`)).text();
        await conn.sendFile(m.chat, resultss, 'error.mp4', '*Aqui tiene ฅ^•ﻌ•^ฅ*', m);
        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
      } catch {
        try {
          const resultssss = await instagramdl(args[0]);
          const shortUrl3 = await (await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`)).text();
          for (const {url} of resultssss) await conn.sendFile(m.chat, url, 'error.mp4', '*Aqui tiene ฅ^•ﻌ•^ฅ*', m);
          await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
        } catch {
          try {
            const human = await fetch(`https://api.lolhuman.xyz/api/instagram?apikey=${lolkeysapi}&url=${args[0]}`);
            const json = await human.json();
            const videoig = json.result;
            const shortUrl1 = await (await fetch(`https://tinyurl.com/api-create.php?url=${args[0]}`)).text();
            await conn.sendFile(m.chat, videoig, 'error.mp4', '*Aqui tiene ฅ^•ﻌ•^ฅ*', m);
            await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
          } catch {
            throw `*-  NINO   BOT   -   ERROR  -* 」\n\nOcurrió un *Error*`;
          }
        }
      }
    }
  }
};
handler.help = ['instagram *<link ig>*'];
handler.tags = ['downloader'];
handler.command = /^(instagramdl|instagram|igdl|ig|instagramdl2|instagram2|igdl2|ig2|instagramdl3|instagram3|igdl3|ig3)$/i;
handler.limit = 1
handler.register = true 
export default handler;

const getBuffer = async (url, options) => {
    options = options || {};
    const res = await axios({method: 'get', url, headers: {'DNT': 1, 'Upgrade-Insecure-Request': 1}, ...options, responseType: 'arraybuffer'});
    const buffer = Buffer.from(res.data, 'binary');
    const detectedType = await fileTypeFromBuffer(buffer);
    if (!detectedType || (detectedType.mime !== 'image/jpeg' && detectedType.mime !== 'image/png' && detectedType.mime !== 'video/mp4')) {
        return null;
    }
    return { buffer, detectedType };
};