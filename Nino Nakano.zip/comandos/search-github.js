import fetch from 'node-fetch'

let handler = async (m, { text, command, usedPrefix }) => {
    if (!text) throw `*Formato incorrecto*\n*Ejemplo:*\n${usedPrefix + command} <nombre>`
    let res = await fetch(global.API('https://api.github.com', '/search/repositories', {
        q: text
    }))
    let json = await res.json()
    if (res.status !== 200) throw json
    let str = json.items.map((repo, index) => {
        return `
${1 + index}. *${repo.full_name}*${repo.fork ? ' (copia)' : ''}
${repo.html_url}
✰ Creado en *${formatDate(repo.created_at)}*
✰ Última actualización en *${formatDate(repo.updated_at)}*
${repo.watchers}   ${repo.forks}   ${repo.stargazers_count}
${repo.open_issues} ✰ Problema${repo.description ? `
*✰ Descripción:*\n${repo.description}` : ''}
*✰ Clonar:* \`\`\`$ git clone ${repo.clone_url}\`\`\`
`.trim()
    }).join('\n\n')
    m.reply(str)
}

handler.help = ['githubsearch']
handler.tags = ['search']
handler.command = /^g(ithub|h)s(earch)?$/i
export default handler

function formatDate(n, locale = 'es') {
    let d = new Date(n)
    return d.toLocaleDateString(locale, {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
}