import {search, download} from 'aptoide-scraper';
const handler = async (m, { conn, text, args, usedPrefix, command }) => {
  if (!text) throw `*• Ingresα el título de unα cαnción*\n\n*Ejemplo:*\n*${usedPrefix + command}* WhatsApp`;
  await conn.sendMessage(m.chat, { react: { text: '🕜', key: m.key }});
  try {
    const searchA = await search(text);
    const data5 = await download(searchA[0].id);
     if (data5.size.includes('GB') || data5.size.replace(' MB', '') > 200) {
      return await conn.sendMessage(m.chat, {text: 'El archivo pesa mas de 200 MB, se canceló la Descarga.'}, {quoted: m});
    }
    await conn.sendMessage(m.chat, {document: {url: data5.dllink}, mimetype: 'application/vnd.android.package-archive', fileName: data5.name + '.apk', caption: null}, {quoted: m});
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }});
  } catch {
    throw `*-  NINO   BOT   -   ERROR  -\n\nOcurrió un *Error*`;
  }    
};
handler.help = ['apkdl'];
handler.tags = ['downloader'];
handler.command = /^(apkdl|apk|apkmod|modapk|dapk2)$/i;
handler.register = true
handler.limit = 5
export default handler;