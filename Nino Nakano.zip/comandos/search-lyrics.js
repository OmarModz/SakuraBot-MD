import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
   if (!text) throw `🚩 Ingresa el título de una canción.\n\n*Ejemplo:*\n*${usedPrefix + command}* Alan Walker - Sing Me To Sleep`
   await m.react('🕓')
   try {
   let res = await fetch('https://api.popcat.xyz/lyrics?song=' + encodeURIComponent(text))
   if (!res.ok) return 
   let json = await res.json()
   if (!json.lyrics) return m.reply('Letra no encontrada, intenta con otro Titulo.')
   let txt = `\t\t\t*乂  L Y R I C S  -  S E A R C H*\n\n`
      txt += `*✰ Titulo* : ${json.title}\n`
      txt += `*✰Artista* : ${json.artist}\n\n`
      txt += `${json.lyrics}`
   let img = await (await fetch(json.image)).buffer()

await conn.sendFile(m.chat, img, 'thumbnail.jpg', txt, m)
await m.react('✅')
} catch (error) {
m.react('✖️')
}}
handler.help = ['lyrics']
handler.tags = ['search']
handler.command = ['lyrics', 'lyric', 'letra']
handler.register = true 
//handler.limit = 1

export default handler