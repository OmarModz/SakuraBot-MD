import db from '../lib/database.js'
let linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})( [0-9]{1,3})?/i

let handler = async (m, { conn, text, isOwner, usedPrefix, command }) => {
	
	if (!text) throw `⚠️️ *_Envie el link de tu Grupo_*\n\n📌 *_Ejemplo_* *${usedPrefix + command}* https://chat.whatsapp.com/La4sJ0SeygtJs6hexdiuV7`
    let [_, code, expired] = text.match(linkRegex) || []
    if (!code) throw '⚠️Link invalido'
    let res = await conn.groupAcceptInvite(code)
    expired = Math.floor(Math.min(999, Math.max(1, isOwner ? isNumber(expired) ? parseInt(expired) : 0 : 3)))
    m.reply(`*_✅ Me uní correctamente al grupo ${res}${expired ? ` Durante ${expired} días_*` : ''}`)
    let chats = global.db.data.chats[res]
    if (!chats) chats = global.db.data.chats[res] = {}
    if (expired) chats.expired = +new Date() + expired * 1000 * 60 * 60 * 24
    let pp = 'https://telegra.ph/file/4fa3f65b6698517cd8dcf.mp4'
   await conn.sendMessage(res, { video: { url: pp }, gifPlayback: true, caption: 'Eh llegado\nDespues de mucha Paja', mentions: [m.sender] }, { quoted: estilo })
}
handler.help = ['join *<link>*']
handler.tags = ['owner']

handler.command = ['join', 'entrar'] 
handler.owner = true

export default handler

const isNumber = (x) => (x = parseInt(x), typeof x === 'number' && !isNaN(x))