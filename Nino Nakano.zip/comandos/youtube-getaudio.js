import fetch from 'node-fetch'
import yts from 'yt-search'
import { youtubedl, youtubedlv2 } from '@bochilteam/scraper';
let limit = 100 
let handler = async (m, { conn, text, isPrems, isOwner, usedPrefix, command }) => {
	if (!text) return m.reply('Ingresa el nro de un resultado de YouTube Search.') 
	if (!m.quoted) return m.reply('Etiqueta el mensaje que contenga el resultado de YouTube Search.') 
	if (!m.quoted.text.includes("乂  Y O U T U B E  -  S E A R C H")) return m.reply('Etiqueta el mensaje que contenga el resultado de YouTube Search.') 
	if (!m.quoted.isBaileys) return m.reply('Etiqueta un mensaje mio que contenga el resultado de YouTube Search.') 
	let urls = m.quoted.text.match(new RegExp(/(?:https?:\/\/)?(?:youtu\.be\/|(?:www\.|m\.)?youtube\.com\/(?:watch|v|embed|shorts)(?:\.php)?(?:\?.*v=|\/))([a-zA-Z0-9\_-]+)/, 'gi'))
	if (!urls) return m.reply('El mensaje que etiquetaste no contiene el resultado de YouTube Search.') 
	if (urls.length < text) return m.reply('Resultado no Encontrado.') 
	await m.react('🕓')
	try {
	let q = '128kbps'
	let v = urls[text - 1]
	let yt = await youtubedl(v).catch(async () => await youtubedlv2(v))
	let url = await yt.audio[q].download()
	let title = await yt.title
	let size = await yt.audio[q].fileSizeH
	if (size.split('MB')[0] >= limit) return m.reply(`El archivo pesa mas de ${limit} MB, se canceló la Descarga.`) 
	let txt = `\t\t\t*乂  Y O U T U B E  -  M P 3*\n\n`
       txt += `*✥Titulo ∙* ${title}\n`
       txt += `*✥Calidad ∙* ${q}\n`
       txt += `*✥Tamaño ∙* ${size}\n\n`
       txt += `- El audio se esta enviando, Espere un momento.`
await conn.sendFile(m.chat, yt.thumbnail, 'play', txt, m)
await conn.sendMessage(m.chat, { audio: { url: url }, fileName: title + '.mp3', mimetype: 'audio/mp4' }, { quoted: m })
await m.react('✅')
} catch {
await m.reply(`${global.error}`)
}}

handler.help = ['getaudio']
handler.tags = ['downloader']
handler.command = ['audio', 'getaudio']
handler.limit = 1
handler.register = true 

export default handler