import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
   if (!text) return m.reply('*• Ingresα el nombre de un αnime*')
   await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
   let res = await fetch('https://api.jikan.moe/v4/anime?q=' + encodeURIComponent(text))
   let json = (await res.json()).data
   let txt = `\t\t\t*乂  A N I M E  -  I N F O*\n\n`
      txt += `*Titulo* : ${json[0].title}\n`
	  txt += `*Id* : ${json[0].mal_id}\n`
	  txt += `*Tipo* : ${json[0].type}\n`
	  txt += `*Episodios* : ${json[0].episodes}\n`
	  txt += `*Estado* : ${json[0].status}\n`
	  txt += `*Emitido* : ${json[0].aired.string}`
	  txt += `*Clasificacion* : ${json[0].rating}\n`
	  txt += `*Duracion* : ${json[0].duration}\n`
	  txt += `*Puntaje* : ${json[0].score}\n`
	  txt += `*Genero* : ${json[0].genres.map((val) => val.name).join(", ")}\n`
	  txt += `*Sinopsis* : ${json[0].synopsis}\n\n`
   let img = await (await fetch(json[0].images.jpg.large_image_url)).buffer()
   conn.sendMessage(m.chat, {
text: txt,
contextInfo: { 
forwardingScore: 9999, 
isForwarded: true, 
externalAdReply: {
title: botname,
body: 'bodynya',
thumbnailUrl: json[0].images.jpg.large_image_url,
sourceUrl: [global.linkgc, global.linkgc2, global.linkgc3, global.linkgc4, global.linkgc5].getRandom(),
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
   await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}

handler.help = ['animeinfo']
handler.tags = ['search']
handler.command = ['anime-info', 'animeinfo', 'infonime']

export default handler

/*import translate from '@vitalets/google-translate-api'
import { Anime } from "@shineiichijo/marika"
const client = new Anime();
let handler = async(m, { conn, text, usedPrefix }) => {
if (!text) return m.reply(`*• Ingresα el nombre de un αnime*`)
await conn.sendMessage(m.chat, { react: { text: '🔎', key: m.key }})
try {  
let anime = await client.searchAnime(text)
let result = anime.data[0];
let resultes = await translate(`${result.background}`, { to: 'es', autoCorrect: true })   
let resultes2 = await translate(`${result.synopsis}`, { to: 'es', autoCorrect: true })   
let AnimeInfo = `
*Título ∙* ${result.title}
*Formαto ∙* ${result.type}
*Estαdo ∙* ${result.status.toUpperCase().replace(/\_/g, " ")}
*Episodios totales ∙* ${result.episodes}
*Durαción:* ${result.duration}
*Bαsαdo en ∙* ${result.source.toUpperCase()}
*Estrenαdo ∙* ${result.aired.from}
*Finalizαdo ∙* ${result.aired.to}
*Populαridαd ∙* ${result.popularity}
*Fαvoritos ∙* ${result.favorites}
*Clαsificαción ∙* ${result.rating}
*Rαngo ∙* ${result.rank}
*Trailer ∙* ${result.trailer.url}
*URL ∙* ${result.url}
*Bαckground ∙* ${resultes.text}
*Ringkαsαn ∙* ${resultes2.text}`
conn.sendFile(m.chat, result.images.jpg.image_url, 'error.jpg', AnimeInfo, m)
} catch {
throw `*STAFF* | Error\n\n*Vuelve α intentαrlo*`  
}}
handler.help = ['animeinfo'] 
handler.tags = ['search']
handler.command = /^(anime|animeinfo)$/i
export default handler */
