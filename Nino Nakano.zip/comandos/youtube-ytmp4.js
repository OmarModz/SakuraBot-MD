import { youtubedl, youtubedlv2 } from '@bochilteam/scraper'
import fetch from 'node-fetch'
let limit = 100
let handler = async (m, { conn, args, isPrems, isOwner, usedPrefix, command }) => {
	if (!args || !args[0]) throw `🍭 Ingresa un enlace del vídeo de YouTube.`
	if (!args[0].match(/youtu/gi)) return m.reply(`Verifica que el enlace sea de YouTube.`)
	try {
	let q = args[1] || '480p'
	let v = args[0]
	let yt = await youtubedl(v).catch(async () => await youtubedlv2(v))
	let url = await yt.video[q].download()
	let title = await yt.title
	let size = await yt.video[q].fileSizeH  
	if (size.split('MB')[0] >= limit) return m.reply(`El archivo pesa mas de ${limit} MB, se canceló la Descarga.`) 
	let txt = `\t\t*三玖 YᴏᴜTᴜʙᴇ Vɪᴅᴇᴏ MP4 玖三*\n\n`
       txt += `*✥ Tɪᴛᴜʟᴏ* : ${title}\n`
       txt += `*✥ Cᴀʟɪᴅᴀᴅ* : ${q}\n`
       txt += `*✥ Pᴇsᴏ* : ${size}\n\n`
       txt += `*- ↻ El video se esta enviando espera un momento, soy lenta. . .*`
await conn.sendFile(m.chat, yt.thumbnail, 'thumbnail.jpg', txt, m)
await conn.sendMessage(m.chat, { video: { url: url }, fileName: title + '.mp4', mimetype: 'video/mp4', caption: `*✥ Tɪᴛᴜʟᴏ* : ${title}\n*✥ Cᴀʟɪᴅᴀᴅ* : ${q}`, thumbnail: await fetch(yt.thumbnail) }, { quoted: m })
} catch {
}}
handler.help = ['ytmp4 <link yt>']
handler.tags = ['downloader']
handler.command = ['ytmp4', 'ytv', 'yt']
//handler.limit = 1
handler.register = true 

export default handler