import yts from 'yt-search'

let handler = async (m, {conn, usedPrefix, text }) => {
   if (!text) return conn.reply(m.chat, '🍭 Ingresa lo que deseas buscar en YouTube.', m)
   let results = await yts(text)
   let res = results.all.map(v => v).filter(v => v.type == "video")
   if (!res.length) return conn.reply(m.chat, 'No se encontraron resultados, intente con un nombre más Corto.', m)
   let txt = `\t\t*YouTube - Search*`
   for (let i = 0; i < (30 <= res.length ? 30 : res.length); i++) {
      txt += `\n\n`
	  txt += `*✥ Tɪᴛᴜʟᴏ* : ${res[i].title}\n`
	  txt += `*✥ Dᴜʀᴀᴄɪᴏɴ* : ${res[i].timestamp || '×'}\n`
	  txt += `*✥ Pᴜʙʟɪᴄᴀᴅᴏ* : ${res[i].ago}\n`
	  txt += `*✥ Aᴜᴛᴏʀ* : ${res[i].author.name || '×'}\n`
	  txt += `*✥ Uʀʟ* : ${'https://youtu.be/' + res[i].videoId}`
	  }
   await conn.sendFile(m.chat, res[0].image, '', txt, m)
}
handler.help = ['ytsearch <búsqueda>']
handler.tags = ['search']
handler.command = ['ytsearch', 'yts']
handler.register = true 
export default handler