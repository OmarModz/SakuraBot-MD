let handler = async (m, { conn, usedPrefix, isOwner }) => {
    let user = global.db.data.users[m.sender]
    const data = global.owner.filter(([id, isCreator]) => id && isCreator)
let texto1 = `Hola @${m.sender.split`@`[0]} si necesitas la ayuda de mi creador porfavor escribele al privado\n*-Solo asuntos importantes-*`
await conn.sendMessage(m.chat, { react: { text: '😺', key: m.key }})
await conn.reply(m.chat, `Hola @${m.sender.split`@`[0]} si necesitas la ayuda de mi creador porfavor escribele al privado\n*- Solo asuntos importantes -*`, estilo, { mentions: [m.sender] })
let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:;おYᴏsᴍᴇʀ.ᴅɢ;;\nFN:おYᴏsᴍᴇʀ.ᴅɢ\nORG:おYᴏsᴍᴇʀ.ᴅɢ\nTITLE:\nitem1.TEL;waid=51978291185:51978291185\nitem1.X-ABLabel:おYᴏsᴍᴇʀ.ᴅɢ\nX-WA-BIZ-DESCRIPTION:\nX-WA-BIZ-NAME:おYᴏsᴍᴇʀ.ᴅɢ\nEND:VCARD`
await conn.sendMessage(m.chat, { contacts: { displayName: 'おYᴏsᴍᴇʀ.ᴅɢ', contacts: [{ vcard }] }}, {quoted: m})
}
handler.customPrefix = /^(@51978291185|@13477688485|@51944114076)$/i
handler.command = new RegExp
export default handler