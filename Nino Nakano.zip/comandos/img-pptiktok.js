import fetch from 'node-fetch'
let handler = async (m, { conn, args, text }) => {
if (!text) throw '*• Ingresa el nombre de usuario de Tiktok*'
let res = `https://api.lolhuman.xyz/api/pptiktok/${text}?apikey=${lolkeysapi}`
conn.sendFile(m.chat, res, 'error.jpg', `*Aquí esta la foto de perfil de:* *${text}*`, fakemsg)
handler.help = ['tiktokfoto'].map(v => v + ' *<username>*')
handler.tags = ['img']
handler.command = /^(tiktokfoto|pptiktok)$/i
handler.limit = 1
handler.register = true 
export default handler