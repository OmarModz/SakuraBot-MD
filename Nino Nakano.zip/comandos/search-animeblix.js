import axios from 'axios'
import cheerio from 'cheerio'
import fetch from 'node-fetch'

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  if (!text) return conn.reply(m.chat, `*• Ingresa nombre de un Anime que deseas buscar*\n\n*Ejemplo:*\n*${usedPrefix + command}* Oshi No Ko`, m) 
  await m.react('🕓') 
  try {
    let response = await axios.get(`https://animeblix.xyz/animes?name=${text}`)
    let html = response.data
    
    let $ = cheerio.load(html)
    let results = []
    let resultUrls = []
    
    $('.animeListItemShadow__h h3').each((index, element) => {
      let title = $(element).text().trim()
      let url = $(element).parent().siblings('.animeListItemShadow__l').attr('href')
      results.push(title)
      resultUrls.push(url)
    })

    let imageUrl = $('.animeListItemShadow__f img').attr('data-src')
    
    if (results.length > 0) {
      let txt = `\t\t\t*乂  A N I M E B L I X  -  S E A R C H*`
      for (let i = 0; i < (50 <= results.length ? 50 : results.length); i++) {
        txt += `\n\n`
        txt += `*✰ Nro ∙* ${1 + i}\n`
        txt += `*✰ Nombre ∙* ${results[i]}\n`
        txt += `*✰ Url ∙* ${resultUrls[i]}`
      }
      let img = await (await fetch(`${imageUrl}`)).buffer()
      
      if (imageUrl) {
    await conn.sendMessage(m.chat, {
      text: txt,
      contextInfo: {
        forwardingScore: 9999,
        isForwarded: true,
        externalAdReply: {
          title: botname,
          body: textbot,
          thumbnailUrl: img,
          thumbnail: img,
          sourceUrl: null,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })
        await m.react('✅')
      } else {
        conn.reply(m.chat, `No se encontraron resultados para ${text}`, m)
      }
    } else {
      conn.reply(m.chat, `No se encontraron resultados para ${text}`, m)
    }
  } catch {
    m.reply(`${global.error}`)
  }
}
handler.tags = ['search']
handler.help = ['animeblix *<name anime>*']
handler.command = ['animeblix']
handler.limit = 1
handler.register = true

export default handler 