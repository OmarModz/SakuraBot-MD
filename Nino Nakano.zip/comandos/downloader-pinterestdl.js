let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    if (!args || !args[0]) return conn.reply(m.chat, `🚩 Ingresa el enlace de algún Pin de Pinterest.`, m)
    await m.react('🕓')
    try {
        let api = await fetch(`https://api.betabotz.eu.org/api/download/pinterest?url=${args[0]}&apikey=${betabotz}`)
        let data = await api.json()
        
        if (data.result.success) {
            let res = data.result.data
            let dl_url = res.image
            let type = res.media_type
            let title = res.title

            await conn.sendFile(m.chat, dl_url, 'tovid.mp4', `*» Título* : ${title}` , m)
            await m.react('✅')
        } else {
            await m.react('✖️')
        }
    } catch (error) {
        await m.react('✖️')
    }
}
handler.tags = ['downloader']
handler.help = ['pinterestdl *<url pin>*']
handler.command = ['pindl', 'pinterestdl']
handler.register = true
export default handler