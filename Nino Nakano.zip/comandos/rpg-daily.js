const free = 9000;
const prem = 200000;
const cooldowns = {};

let handler = async (m, { conn, isPrems }) => {
  let user = global.db.data.users[m.sender];
  const tiempoEspera = 24 * 60 * 60;
  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera * 1000) {
    const tiempoRestante = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempoEspera * 1000 - Date.now()) / 1000));
    m.reply(`*Miku Bot - MD* | 「 *CLAIM* 」\n\nYa has realizado tu pedido gratis de hoy.\nRecuerda que solo puedes realizarlo 1 vez cada 24 horas.\n\n*Próximo Monto* : +${isPrems ? prem : free}\n*En* : ${tiempoRestante}`)
    return;
  }

  global.db.data.users[m.sender].exp += isPrems ? prem : free;
  m.reply(`*Miku Bot - MD* | 「 *CLAIM* 」\n\n*Acabas de reclamar tu pedido de hoy:*\n\nEstos son tus *+${isPrems ? prem : free} XP* diarios`);

  cooldowns[m.sender] = Date.now();
};


handler.help = ['claim'];
handler.tags = ['rpg'];
handler.command = ['daily', 'claim'];
handler.register = true;

export default handler;

function segundosAHMS(segundos) {
  const horas = Math.floor(segundos / 3600);
  const minutos = Math.floor((segundos % 3600) / 60);
  const segundosRestantes = segundos % 60;
  return `${horas} horas, ${minutos} minutos y ${segundosRestantes} segundos`;
}



/*const free = 9000
const prem = 50000

let handler = async (m, {conn, isPrems }) => {
  let time = global.db.data.users[m.sender].lastclaim + 86400000
  if (new Date - global.db.data.users[m.sender].lastclaim < 86400000) throw `*Miku Bot - MD* | 「 *CLAIM* 」\n\nYa Has realizado tu pedido gratis de hoy.\nRecuerda que solo puedes realizarlo 1 vez cada 24 horas.\n\n*Próximo Monto* : +${isPrems ? prem : free}\n*En* : ${msToTime(time - new Date())}`
  global.db.data.users[m.sender].exp += isPrems ? prem : free
  m.reply(`*Miku Bot - MD* | 「 *CLAIM* 」\n\n*Acabas de reclamar tu pedido de hoy:*

estos son tus *+${isPrems ? prem : free} XP* diarios`)
  global.db.data.users[m.sender].lastclaim = new Date * 1
}
handler.help = ['claim']
handler.tags = ['rpg']
handler.command = ['daily', 'claim'] 
handler.register = true 

export default handler



function msToTime(duration) {
  var milliseconds = parseInt((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24)

  hours = (hours < 10) ? "0" + hours : hours
  minutes = (minutes < 10) ? "0" + minutes : minutes
  seconds = (seconds < 10) ? "0" + seconds : seconds

  return hours + " Horas " + minutes + " Minutos"
}*/