let handler = async (m, { conn, usedPrefix, isOwner }) => {
    let user = global.db.data.users[m.sender]
    const data = global.owner.filter(([id, isCreator]) => id && isCreator)
let vcard = `BEGIN:VCARD\nVERSION:3.0\nN:;おYᴏsᴍᴇʀ.ᴅɢ;;\nFN:おYᴏsᴍᴇʀ.ᴅɢ\nORG:おYᴏsᴍᴇʀ.ᴅɢ\nTITLE:\nitem1.TEL;waid=51978291185:51978291185\nitem1.X-ABLabel:おYᴏsᴍᴇʀ.ᴅɢ\nX-WA-BIZ-DESCRIPTION:\nX-WA-BIZ-NAME:おYᴏsᴍᴇʀ.ᴅɢ\nEND:VCARD`
await conn.sendMessage(m.chat, { contacts: { displayName: 'おYᴏsᴍᴇʀ.ᴅɢ', contacts: [{ vcard }] }}, {quoted: m})
}
handler.help = ['owner']
handler.tags = ['main']
handler.command = ['owner', 'creator', 'creador', 'dueño'] 

export default handler