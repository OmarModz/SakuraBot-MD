let handler = m => m

handler.before = async function (m) {

    let forbidPrefixes = ["212", "265", "234", "258", "263", "93", "967", "92", "234", "91", "254", "213"]

    for (let prefix of forbidPrefixes) {
      if (m.sender.startsWith(prefix)) {
   	global.db.data.users[m.sender].banned = false
   	await m.reply(`Hola *@${m.sender.split`@`[0]}*, los números extranjeros no tienen permitido escribir al privado de la Bot`, false, { mentions: [m.sender] })
   	await this.updateBlockStatus(m.chat, 'block')
   	}}}

export default handler