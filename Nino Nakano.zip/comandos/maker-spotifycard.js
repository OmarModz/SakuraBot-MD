import fetch from 'node-fetch'

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  let inputs = args.join(' ').split('|')
  
  if (inputs.length !== 4) throw `*• Por favor, ingresa 3 textos y una URL separados por '|'*\n\n*Ejemplo:*\n*${usedPrefix + command}* Idol|Ai Hoshino|Oshi No Ko|https://tinyurl.com/yl382vxw`
  
  let [text1, text2, text3, imgUrl] = inputs
  
  if (!(text1 && text2 && text3 && imgUrl)) throw `*• Ingresa 3 textos y una URL válida*`
  
  await m.react('🕓')
  
  let res = `https://api.yanzbotz.my.id/api/maker/spotify-card?author=${text1}&title=${text2}&album=${text3}&img=${imgUrl}`
  
  await conn.sendFile(m.chat, res, 'thumbnail.jpg', listo, m)
  
  await m.react('✅')
}
handler.help = ['spotifycard *<autor|título|álbum|url img>*']
handler.tags = ['logo']
handler.command = /^(spotifycard)$/i
handler.register = true 
//handler.limit = 1
export default handler