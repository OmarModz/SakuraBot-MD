/*import fg from 'api-dylux' 
import { tiktokdl } from '@bochilteam/scraper'
let handler = async (m, { conn, text, args, usedPrefix, command}) => {
if (!args[0]) throw `🚩 Ingresa el enlace del vídeo de TikTok.`
if (!args[0].match(/tiktok/gi)) return conn.reply(m.chat, `Verifica que el link sea de TikTok`,  m).then(_ => m.react('✖️'))
await m.react('🕓')
try {
let p = await fg.tiktok(args[0])
await conn.sendFile(m.chat, p.play, "out.png", listo, m)
await m.react('✅')
} catch {
try {
const { video } = await tiktokdl(args[0])
const url = video.no_watermark2 || video.no_watermark || 'https://tikcdn.net' + video.no_watermark_raw || video.no_watermark_hd
if (!url) throw m.react('✖️')
await conn.sendFile(m.chat, url, "out.png", listo, m)
await m.react('✅')
} catch {
await m.react('✖️')
}}}
handler.help = ['tiktok *<url tt>*']
handler.tags = ['downloader']
handler.command = /^(tiktok|ttdl|tiktokdl|tiktoknowm)$/i
//handler.limit = 1
handler.register = true 

export default handler*/