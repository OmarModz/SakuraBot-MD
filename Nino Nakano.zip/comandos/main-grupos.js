let handler  = async (m, { conn, usedPrefix, command }) => {
let text = `*Hola!, te invito a unirte a los grupos oficiales de del Bot para convivir con la comunidad :D*

1- Miku Bot | OFC
▢ ${group}

2- Miku Bot | Sub Bots
▢ ${group2}

3- Miku Bot | OFC III
▢ ${group3}

4- ⭐̊N⭐̊
▢ ${group4}

5- —★ 🎟]「  ϟ ⭐
▢ ${gclink5}

─────────────
≡ Enlaces anulados? entre aquí! 

Grupos : 
▢ https://chat.whatsapp.com/JUbscwIz19iKWHDnXSNoXQ

Canal :
▢ ${canal1}

Canal 2 :
▢ ${canal2}`
m.reply(text)
}

handler.help = ['grupos']
handler.tags = ['main']
handler.command = /^(grupos)$/i
export default handler