let handler = async (m, { conn, text, args, usedPrefix, command }) => {
let response = args.join(' ').split('|')
if (!text) throw `🚩 Ingresa un texto junto al comando.`
await m.react('🕓')
try {
let res = `https://api.popcat.xyz/alert?text=${text}`
await conn.sendFile(m.chat, res, 'thumbnail.jpg', listo, m)
await m.react('✅')
} catch {
await m.react('✖️')
}}
handler.help = ['alerta *<texto>*']
handler.tags = ['logo']
handler.command = /^(alerta|alert)$/i
//handler.limit = 1
handler.register = true 
export default handler