import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, `🚩 Ingresa nombre de un usuario de Instagram.`, m) 
  await m.react('🕓')
  try {
    let api = `https://api.betabotz.eu.org/api/stalk/ig?username=${text}&apikey=${betabotz}`
    let res = await fetch(api)
    let result = await res.json()
    
    if (result.status) {
      let user_info = result.result.user_info
      let txt = `*乂  I N S T A G R A M  -  S T A L K*\n\n`
          txt += `  ✩   *Username* : ${user_info.username}\n`
          txt += `  ✩   *Nombre* : ${user_info.full_name}\n`
          txt += `  ✩   *Biografía* : ${user_info.biography}\n`
          txt += `  ✩   *URL Externa:* ${user_info.external_url}\n`
          txt += `  ✩   *Cuenta Privada:* ${user_info.is_private ? 'Sí' : 'No'}\n`
          txt += `  ✩   *Cuenta Verificada:* ${user_info.is_verified ? 'Sí' : 'No'}\n`
          txt += `  ✩   *Seguidores:* ${user_info.followers}\n`
          txt += `  ✩   *Siguiendo:* ${user_info.following}\n`
          txt += `  ✩   *Publicaciones:* ${user_info.posts}\n\n`
          txt += `🚩 *${textbot}*`
      
       await conn.sendFile(m.chat, user_info.profile_pic_url, "out.png", txt, m)
       await m.react('✅')
    } else {
      await m.react('✖️')
    }
  } catch (error) {
    await m.react('✖️')
  }
}

handler.tags = ['tools']
handler.help = ['igstalk *<usuario ig>*']
handler.command = ['igstalk']
handler.register = true 
export default handler