import axios from 'axios';

let handler = async (m, { conn, text }) => {
if (!text) return conn.reply(m.chat, `*• Ingresa nombre de un artista o canción que deseas buscar*`, m) 
await m.react('🕓') 
  try {
    let response = await axios.get(`https://api.yanzbotz.my.id/api/cari/soundcloud?query=${text}`)
    let res = response.data.result.data

    let txt = `\t\t\t*乂  S O U N D C L O U D  -  S E A R C H*`
    for (let i = 0; i < (50 <= res.length ? 50 : res.length); i++) {
      txt += `\n\n`
      txt += `*✰ Nro ∙* ${1 + i}\n`
      txt += `*✰ Titulo ∙* ${res[i].title}\n`
      txt += `*✰ Artista ∙* ${res[i].artist}\n`
      txt += `*✰ Genero ∙* ${res[i].genre}\n`
      txt += `*✰ Duracion ∙* ${res[i].duration}\n`
      txt += `*✰ Plays ∙* ${res[i].plays}\n`
      txt += `*✰ Likes ∙* ${res[i].likes}\n`
      txt += `*✰ Comentarios ∙* ${res[i].comments}\n`
      txt += `*✰ Url ∙* ${res[i].url}`
    }
    conn.reply(m.chat, txt, m)
  } catch (error) {
    await m.react('✖️')
  }
}
handler.help = ['soundsearch *<texto>*']
handler.tags = ['search']
handler.command = ['soundcloudsearch', 'soundsearch', 'sounds']
//handler.limit = 1
handler.register = true

export default handler