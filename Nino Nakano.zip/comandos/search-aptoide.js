import fetch from 'node-fetch'
import { search } from 'aptoide-scraper'

let handler = async (m, {conn, usedPrefix, text }) => {
   if (!text) return m.reply('*• Ingresa el nombre del Apk que desea buscar en Aptoide*')
   await conn.sendMessage(m.chat, { react: { text: '🕜', key: m.key }})
   let results = await search(text)
   let res = Object.values(results).map(v => v)
   if (!res.length) return m.reply('⚠️ *_No se encontraron resultados, intente con un nombre más Corto._*').then(_ => m.react('✖️'))
   let txt = `\t\t\t\t*乂  S E A R C H  -  A P T O I D E*`
   for (let i = 0; i < (15 <= res.length ? 15 : res.length); i++) {
      txt += `\n\n`
      txt += `*✰ Nro* : ${1+i}\n`
	  txt += `*✰ Nombre* : ${res[i].name}\n`
	  txt += `*✰ ID* : ${res[i].id}\n`
   }
   await conn.sendMessage(m.chat, {
text: txt,
contextInfo: { 
forwardingScore: 9999, 
isForwarded: true, 
externalAdReply: {
title: botname,
body: 'bodynya',
thumbnailUrl: 'https://telegra.ph/file/e7eae20d14bf755fc4ebb.jpg',
sourceUrl: [global.linkgc, global.linkgc2, global.linkgc3, global.linkgc4, global.linkgc5].getRandom(),
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
   await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
}

handler.help = ['aptoide *<texto>*']
handler.tags = ['search', 'premium']
handler.command = ['aptoide', 'aptoidesearch']
handler.premium = true 
handler.register = true 
export default handler