import db from '../lib/database.js'
import { canLevelUp, xpRange } from '../lib/levelling.js'
import { createHash } from 'crypto'
import PhoneNumber from 'awesome-phonenumber'
import fetch from 'node-fetch'

let handler = async (m, { conn, usedPrefix, command}) => {
  let who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? conn.user.jid : m.sender
  let bio = await conn.fetchStatus(who).catch(_ => 'undefined')
  let biot = bio.status?.toString() || 'Sin Info'
 // let biot = bio.Status(who).catch(_ => 'Sin Bio')
  let user = global.db.data.users[who]
  let pp = await conn.profilePictureUrl(who, 'image').catch(_ => 'https://telegra.ph/file/59a40419dd1fe16e0dd55.jpg')
  let { exp, limit, lastclaim, name, registered, regTime, age, level } = global.db.data.users[who]
  let { min, xp, max } = xpRange(user.level, global.multiplier)
  let username = conn.getName(who)
  let prem = global.prems.includes(who.split`@`[0])
  let sn = createHash('md5').update(who).digest('hex')
  let img = await (await fetch(`${pp}`)).buffer()  
  let str = `*-  P E R F I L  -*
*╭* *Nombre* : ${name}
*│✩* *Edad* : ${registered ? `${age} años` : '×'}
*│✩* *Numero* : ${PhoneNumber('+' + who.replace('@s.whatsapp.net', '')).getNumber('international')}
*│✩* *Link* : wa.me/${who.split`@`[0]}
*│✩* *Coins* : ${limit}
*│✩* *Nivel* : ${level} 
*│✩* *XP* : Total ${exp} (${user.exp - min}/${xp})
*│✩* *Premium* : ${prem ? 'Si' : 'No'}
*│✩* *Ultimo claim* : ${lastclaim > 0 ? `${formatDate(lastclaim)}` : '×'}
*╰* *Registrado* : ${registered ? 'Si': 'No'}`
  let mentionedJid = [who]
  conn.sendFile(m.chat, img, "thumbnail.jpg", str, m)
//conn.sendMessage(m.chat, {
//text: str,
//contextInfo: { 
//mentionedJid,
//forwardingScore: 9999, 
//isForwarded: true, 
//externalAdReply: {
//title: botname,
//body: textbot,
//thumbnailUrl: img,
//thumbnail: img,
//sourceUrl: canal,
//mediaType: 1,
//renderLargerThumbnail: true
//}}}, { quoted: estilo})
//await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
//  conn.sendFile(m.chat, pp, 'Error.jpg', str, m, false, { contextInfo: { mentionedJid }})
}

handler.help = ['perfil', 'perfil *@user*']
handler.tags = ['rg']
handler.command = /^(perfil|profile)$/i
handler.register = true

export default handler


const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function formatDate(n, locale = 'es-US') {
  let d = new Date(n)
  return d.toLocaleDateString(locale, {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  })
}

function formatHour(n, locale = 'en-US') {
  let d = new Date(n)
  return d.toLocaleString(locale, {
    hour: 'numeric',
    minute: 'numeric',
    second: 'numeric',
    hour12: true
  })
}