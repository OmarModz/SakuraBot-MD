import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, `🚩 Ingresa nombre de usuario de GitHub.`, m) 
  await m.react('🕓')
  try {
    let api = `https://api.betabotz.eu.org/api/stalk/github?username=${text}&apikey=${betabotz}`
    let res = await fetch(api)
    let result = await res.json()
    
    if (result.status) {
      let user = result.result.user
      let txt = `*乂  G I T H U B  -  S T A L K*\n\n`
          txt += `  ✩   *Username* : ${user.username}\n`
          txt += `  ✩   *Nombre* : ${user.name}\n`
          txt += `  ✩   *ID de Usuario* : ${user.idUser}\n`
          txt += `  ✩   *URL de GitHub* : ${user.githubUrl}\n`
          txt += `  ✩   *Compañía* : ${user.company || 'Ninguna'}\n`
          txt += `  ✩   *Blog* : ${user.blog}\n`
          txt += `  ✩   *Bio* : ${user.bio}\n`
          txt += `  ✩   *Repositorios Públicos* : ${user.publicRepos}\n`
          txt += `  ✩   *Seguidores* : ${user.followers}\n`
          txt += `  ✩   *Siguiendo* : ${user.following}\n\n`
          txt += `🚩 *${textbot}*`
      
      await conn.sendFile(m.chat, user.avatarUrl, "out.png", txt, m)
      await m.react('✅')
    } else {
      await m.react('✖️')
    }
  } catch {
    await m.react('✖️')
  }
}

handler.tags = ['tools']
handler.help = ['ghstalk *<usuario github>*']
handler.command = ['ghstalk']
handler.register = true 
export default handler