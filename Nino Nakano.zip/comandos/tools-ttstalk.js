import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, `🚩 Ingresa nombre de un usuario de TikTok.`, m) 
  await m.react('🕓')
  try {
    let api = `https://vihangayt.me/stalk/tiktok?q=${text}`
    let res = await fetch(api)
    let result = await res.json()
    
    if (result.status) {
      let txt = `*乂  T I K T O K  -  S T A L K*\n\n`
          txt += `  ✰   *Nombre* : ${result.data.name}\n`
          txt += `  ✰   *Username* : ${result.data.username}\n`
          txt += `  ✰   *Seguidores* : ${result.data.followers}\n`
          txt += `  ✰   *Siguiendo* : ${result.data.following}\n`
          txt += `  ✰   *Likes* : ${result.data.likes}\n\n`
          txt += `🚩 *${textbot}*`
       
       await conn.sendFile(m.chat, result.data.profile, "out.png", txt, m)
      await m.react('✅')
    } else {
      await m.react('✖️')
    }
  } catch {
    try {
      let api = `https://api.betabotz.eu.org/api/stalk/tt?username=${text}&apikey=${betabotz}`
      let res = await fetch(api)
      let result = await res.json()
      
      if (result.status) {
        let txt = `*乂  T I K T O K  -  S T A L K*\n\n`
          txt += `  ✰   *Nombre* : ${result.result.username}\n`
          txt += `  ✰   *Descripción* : ${result.result.description}\n`
          txt += `  ✰   *Seguidores* : ${result.result.followers}\n`
          txt += `  ✰   *Siguiendo* : ${result.result.following}\n`
          txt += `  ✰   *Likes* : ${result.result.likes}\n\n`
          txt += `🚩 *${textbot}*`
         
         await conn.sendFile(m.chat, result.result.profile, "out.png", txt, m)
        await m.react('✅')
      } else {
        await m.react('✖️')
      }
    } catch {
      await m.react('✖️')
    }
  }
}
handler.tags = ['tools']
handler.help = ['ttstalk *<user tt>*']
handler.command = ['ttstalk', 'tiktokstak']
//handler.limit = 1 
handler.register = true 
export default handler