import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, `🚩 Ingresa el nombre del repositorio de GitHub.`, m) 
  await m.react('🕓')
  try {
    let api = `https://api.betabotz.eu.org/api/stalk/repo?repo=${encodeURIComponent(text)}&apikey=${betabotz}`
    let res = await fetch(api)
    let result = await res.json()
    
    if (result.status) {
      let repo = result.result.items[0]
      let txt = `*乂  R E P O S I T O R I O  -  S T A L K*\n\n`
          txt += `  ✩   *Nombre* : ${repo.fullNameRepo}\n`
          txt += `  ✩   *Nombre del Repositorio* : ${repo.nameRepo}\n`
          txt += `  ✩   *Descripción* : ${repo.description}\n`
          txt += `  ✩   *URL del Repositorio* : ${repo.url_repo}\n`
          txt += `  ✩   *Lenguaje* : ${repo.language}\n`
          txt += `  ✩   *Estrellas* : ${repo.stargazers}\n`
          txt += `  ✩   *Observadores* : ${repo.watchers}\n`
          txt += `  ✩   *Bifurcaciones* : ${repo.forks}\n`
          txt += `  ✩   *Rama predeterminada* : ${repo.defaultBranch}\n`
          txt += `  ✩   *Repositorio privado* : ${repo.isPrivate ? 'Sí' : 'No'}\n`
          txt += `  ✩   *Repositorio de bifurcación* : ${repo.isFork ? 'Sí' : 'No'}\n`
          txt += `  ✩   *Creado en* : ${repo.createdAt}\n`
          txt += `  ✩   *Actualizado en* : ${repo.updatedAt}\n`
          txt += `  ✩   *Último push* : ${repo.pushedAt}\n\n`
          txt += `🚩 *${textbot}*`
      
      await conn.sendFile(m.chat, repo.author.avatar_url, "out.png", txt, m)
      await m.react('✅')
    } else {
      await m.react('✖️')
    }
  } catch {
    await m.react('✖️')
  }
}

handler.tags = ['tools']
handler.help = ['repoinfo *<nombre del repositorio>*']
handler.command = ['repoinfo', 'repostalk']
handler.register = true 
export default handler