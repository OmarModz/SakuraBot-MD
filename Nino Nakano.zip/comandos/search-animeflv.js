import axios from 'axios'
import cheerio from 'cheerio'

let handler = async (m, { conn, usedPrefix, command, text }) => {
if (!text) return conn.reply(m.chat, `*• Ingresa el nombre de un Anime que deseas buscar en AnimeFlv*`, m) 
  await m.react('🕓') 
  try {  
    let fetchAnimeInfo = async () => {
        let url = `https://m.animeflv.net/browse?q=${text}`

        try {
            let response = await axios.get(url) 
            let $ = cheerio.load(response.data) 

            let animeList = [] 

            $('.List-Animes .Anime').each((index, element) => {
                let anime = {} 
                anime.name = $(element).find('.Title').text().trim() 
                anime.image = $(element).find('.Image img').attr('src') 
                anime.link = $(element).find('a').attr('href') 
                animeList.push(anime) 
            }) 

            return animeList 
        } catch (error) {
            return [] 
        }
    } 
    
    let animeList = await fetchAnimeInfo() 

    let imageBuffer = await axios.get(`https://m.animeflv.net${animeList[0].image}`, { responseType: 'arraybuffer' }) 

    let txt = `\t\t\t*乂  A N I M E F L V -  S E A R C H*` 
    for (let i = 0; i < (50 <= animeList.length ? 50 : animeList.length); i++) {
        txt += `\n\n`
        txt += `*✰ Nro ∙* ${1 + i}\n` 
        txt += `*✰ Nombre ∙* ${animeList[i].name}\n` 
        txt += `*✰ Url ∙* https://m.animeflv.net${animeList[i].link}\n` 
    }

    await conn.sendFile(m.chat, imageBuffer.data, 'anime.jpg', txt, m)
    await m.react('✅')
  } catch (error) {
    conn.reply(`${global.error}`, m)
  }
}
handler.help = ['animeflv *<anime>*']
handler.tags = ['search']
handler.command = ['animeflv', 'animeflvsearch'] 
handler.register = true 

export default handler