import cheerio from 'cheerio'
import axios from 'axios' 
let handler = async (m, { conn, text, __dirname, usedPrefix, command }) => {
if (!global.db.data.chats[m.chat].nsfw) throw `🚫 El grupo no admite contenido nsfw \n\n Para habilitar escriba \n*${usedPrefix}enable* nsfw`
if (!text) throw '*• Ingresa el nombre de un hentai*';
await conn.sendMessage(m.chat, { react: { text: '🕜', key: m.key }})
let searchResults = await searchHentai(text);
let teks = searchResults.result.map((v, i) => `*Título* : ${v.title}\n*Vistas* : ${v.views}\n*Url* : ${v.url}`).join('\n\n');
let randomThumbnail;
if (searchResults.result.length > 0) {
let randomIndex = Math.floor(Math.random() * searchResults.result.length);
randomThumbnail = searchResults.result[randomIndex].thumbnail;
} else {
randomThumbnail = 'https://pictures.hentai-foundry.com/e/Error-Dot/577798/Error-Dot-577798-Zero_Two.png';
teks = '*Miku Bot😺* | 「 *ERROR* 」\n\nOcurrió un *Error*'; }
conn.sendMessage(m.chat, {
text: teks,
contextInfo: { 
forwardingScore: 9999, 
isForwarded: true, 
externalAdReply: {
title: botname,
body: 'bodynya',
thumbnailUrl: randomThumbnail,
sourceUrl: [global.linkgc, global.linkgc2, global.linkgc3, global.linkgc4, global.linkgc5].getRandom(),
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: m})
await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
//conn.sendFile(m.chat, randomThumbnail, 'error.jpg', teks, m);
}
handler.tags = ['nsfw', 'search']
handler.help = ['hentaisearch']
handler.command = /^(hentaisearch|searchhentai)$/i
handler.limit = 2
handler.register = true 
export default handler
async function searchHentai(search) {
return new Promise((resolve, reject) => { axios.get("https://hentai.tv/?s=" + search).then(async ({data}) => {
let $ = cheerio.load(data);
let result = {};
let res = [];
result.coder = 'rem-comp';
result.result = res;
result.warning = "It is strictly forbidden to reupload this code, copyright © 2022 by rem-comp";
$('div.flex > div.crsl-slde').each(function(a, b) {
let _thumbnail = $(b).find('img').attr('src');
let _title = $(b).find('a').text().trim();
let _views = $(b).find('p').text().trim();
let _url = $(b).find('a').attr('href');
let hasil = { thumbnail: _thumbnail, title: _title, views: _views, url: _url };
res.push(hasil)});
resolve(result)}).catch(err => {
console.log(err)})})}