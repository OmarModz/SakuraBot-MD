let cooldowns = {}

let handler = async (m, { conn }) => {

  let hasil = Math.floor(Math.random() * 5000)
  
  let tiempoEspera = 4 * 60 * 60
  if (cooldowns[m.sender] && Date.now() - cooldowns[m.sender] < tiempoEspera * 1000) {
    let tiempoRestante = segundosAHMS(Math.ceil((cooldowns[m.sender] + tiempoEspera * 1000 - Date.now()) / 1000))
    m.reply(`*Miku Bot - MD* | 「 *MINERIA* 」\n\nYa has minado recientemente, espera *${tiempoRestante}* para regresar a la Mina`)
    return
  }
  
  global.db.data.users[m.sender].exp += hasil
  let txt = `*Miku Bot - MD* | 「 *MINERIA* 」\n\n`
      txt += `Genial! minaste *${hasil} XP*`

  await m.reply(txt)
  
  cooldowns[m.sender] = Date.now()
}
handler.help = ['minar']
handler.tags = ['rpg']
handler.command = ['minar', 'miming', 'mine'] 
handler.register = true 
export default handler

function segundosAHMS(segundos) {
  let horas = Math.floor(segundos / 3600)
  let minutos = Math.floor((segundos % 3600) / 60)
  let segundosRestantes = segundos % 60
  return `${horas} horas, ${minutos} minutos y ${segundosRestantes} segundos`
}