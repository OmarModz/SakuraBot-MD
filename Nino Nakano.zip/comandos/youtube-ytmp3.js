import { youtubedl, youtubedlv2 } from '@bochilteam/scraper'
import fetch from 'node-fetch'
let limit = 100
let handler = async (m, { conn, text, args, isPrems, isOwner, usedPrefix, command }) => {
	if (!args || !args[0]) throw `🍭 Ingresa el enlace del vídeo de YouTube.`
	if (!args[0].match(/youtu/gi)) return m.reply(`Verifica que el enlace sea de YouTube.`) 
	try {
	let q = '128kbps'
	let v = args[0]
	let yt = await youtubedl(v).catch(async () => await youtubedlv2(v))
	let url = await yt.audio[q].download()
	let title = await yt.title
	let size = await yt.audio[q].fileSizeH
	if (size.split('MB')[0] >= limit) return m.reply(`El archivo pesa mas de ${limit} MB, se canceló la Descarga.`) 
	let txt = `\t\t*三玖 YᴏᴜTᴜʙᴇ Aᴜᴅɪᴏ MP3 玖三*\n\n`
       txt += `*✥ Tɪᴛᴜʟᴏ* : ${title}\n`
       txt += `*✥ Cᴀʟɪᴅᴀᴅ* : ${q}\n`
       txt += `*✥ Pᴇsᴏ* : ${size}\n\n`
       txt += `*- ↻ El audio se esta enviando espera un momento, soy lenta. . .*`
await conn.sendFile(m.chat, yt.thumbnail, 'thumbnail.jpg', txt, m)
await conn.sendMessage(m.chat, { audio: { url: url }, fileName: title + '.mp3', mimetype: 'audio/mp4' }, { quoted: m })
} catch {
}}
handler.help = ['ytmp3 <link yt>']
handler.tags = ['downloader']
handler.command = ['ytmp3', 'yta', 'fgmp3']
//handler.limit = 1
handler.register = true 

export default handler